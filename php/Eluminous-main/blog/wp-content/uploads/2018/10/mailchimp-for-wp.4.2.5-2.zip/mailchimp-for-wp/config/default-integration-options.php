<?php
return array(
    'css'           => 0,
    'double_optin'  => 1,
	'enabled'       => 0,
	'implicit'      => 0,
	'label'         => __( 'Sign me up for the newsletter!', 'mailchimp-for-wp' ),
    'lists'         => array(),
	'precheck'      => 0,
    'replace_interests' => 0,
	'update_existing' => 0,
    'wrap_p' => 1
);
