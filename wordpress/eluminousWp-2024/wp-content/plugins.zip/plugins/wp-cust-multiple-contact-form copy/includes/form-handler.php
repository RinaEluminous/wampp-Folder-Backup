<?php
function ccf_handle_form_submission() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ccf_submit'])) {
        // Validate and sanitize form input.
        $form_data = array();
        foreach ($_POST as $key => $value) {
            if ($key !== 'ccf_submit') {
                $form_data[$key] = sanitize_text_field($value);
            }
        }

        // Perform your form processing here.
        // Example: Send an email or save to the database.
        // Ensure you handle any errors during processing.

        // For example, sending an email:
        $to = 'your-email@example.com'; // Replace with your email
        $subject = 'New Contact Form Submission';
        $message = 'Form Data: ' . print_r($form_data, true);
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        if (wp_mail($to, $subject, $message, $headers)) {
            wp_redirect(add_query_arg('ccf_status', 'success', get_permalink()));
            exit;
        } else {
            wp_redirect(add_query_arg('ccf_status', 'error', get_permalink()));
            exit;
        }
    }
}
add_action('init', 'ccf_handle_form_submission');
?>
