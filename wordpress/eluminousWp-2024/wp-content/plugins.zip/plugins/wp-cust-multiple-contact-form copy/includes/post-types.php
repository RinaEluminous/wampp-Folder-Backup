<?php
// Function to register the custom post type for contact forms.
function ccf_register_contact_form_post_type() {
    $labels = array(
        'name' => 'Contact Forms',
        'singular_name' => 'Contact Form',
        'menu_name' => 'Contact Forms',
        'name_admin_bar' => 'Contact Form',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Contact Form',
        'new_item' => 'New Contact Form',
        'edit_item' => 'Edit Contact Form',
        'view_item' => 'View Contact Form',
        'all_items' => 'All Contact Forms',
        'search_items' => 'Search Contact Forms',
        'not_found' => 'No contact forms found.',
        'not_found_in_trash' => 'No contact forms found in Trash.'
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => false,
        'menu_position' => 20,
        'supports' => array('title'),
        'show_in_rest' => true
    );

    register_post_type('ccf_contact_form', $args);
}
add_action('init', 'ccf_register_contact_form_post_type');
?>
