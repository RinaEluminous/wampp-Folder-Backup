<?php
// Function to display contact form via shortcode.
function ccf_display_contact_form($atts) {
    $atts = shortcode_atts(array('id' => 0), $atts, 'ccf_contact_form');
    $post_id = $atts['id'];

    if (!$post_id) {
        return 'No contact form specified.';
    }

    $form_fields_json = get_post_meta($post_id, '_ccf_form_fields', true);
    $form_fields = json_decode($form_fields_json, true);

    if (json_last_error() !== JSON_ERROR_NONE || !is_array($form_fields)) {
        return 'Invalid form fields data.';
    }

    ob_start();
    ?>
    <form action="" method="post" enctype="multipart/form-data">
        <?php foreach ($form_fields as $field) : ?>
            <?php 
            // Decode each field to ensure it's properly formatted.
            $field = json_decode($field, true);
            ?>
            <p>
                <label for="<?php echo esc_attr($field['name']); ?>"><?php echo esc_html($field['label']); ?></label>
                <?php if ($field['type'] == 'text') : ?>
                    <input type="text" id="<?php echo esc_attr($field['name']); ?>" name="<?php echo esc_attr($field['name']); ?>">
                <?php elseif ($field['type'] == 'email') : ?>
                    <input type="email" id="<?php echo esc_attr($field['name']); ?>" name="<?php echo esc_attr($field['name']); ?>">
                <?php elseif ($field['type'] == 'textarea') : ?>
                    <textarea id="<?php echo esc_attr($field['name']); ?>" name="<?php echo esc_attr($field['name']); ?>"></textarea>
                <?php elseif ($field['type'] == 'file') : ?>
                    <input type="file" id="<?php echo esc_attr($field['name']); ?>" name="<?php echo esc_attr($field['name']); ?>">
                <?php endif; ?>
            </p>
        <?php endforeach; ?>
        <p>
            <input type="submit" name="ccf_submit" value="Submit">
        </p>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('ccf_contact_form', 'ccf_display_contact_form');

// Display shortcode in form listing page.
function ccf_add_shortcode_column($columns) {
    $columns['shortcode'] = 'Shortcode';
    return $columns;
}
add_filter('manage_ccf_contact_form_posts_columns', 'ccf_add_shortcode_column');

function ccf_shortcode_column_content($column, $post_id) {
    if ($column == 'shortcode') {
        echo '[ccf_contact_form id="' . $post_id . '"]';
    }
}
add_action('manage_ccf_contact_form_posts_custom_column', 'ccf_shortcode_column_content', 10, 2);
