<?php
// Function to add meta boxes for the custom post type.
function ccf_add_meta_boxes() {
    add_meta_box(
        'ccf_contact_form_fields',
        'Form Fields',
        'ccf_render_form_fields_meta_box',
        'ccf_contact_form',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'ccf_add_meta_boxes');

// Callback function to render the form fields meta box.
function ccf_render_form_fields_meta_box($post) {
    wp_nonce_field('ccf_save_meta_box_data', 'ccf_meta_box_nonce');

    // Retrieve and decode form fields.
    $form_fields_json = get_post_meta($post->ID, '_ccf_form_fields', true);
    $form_fields = json_decode($form_fields_json, true);
    
    // Check if JSON decoding was successful and the result is an array.
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($form_fields)) {
        $form_fields = array(); // Default to empty array if error
    }
    ?>
    <div id="ccf-form-builder">
        <ul id="ccf-form-fields">
            <?php foreach ($form_fields as $field) : ?>
                <?php $field = json_decode($field, true); ?>
                <li class="ccf-field">
                    <input type="hidden" name="ccf_form_fields[]" value="<?php echo esc_attr(json_encode($field)); ?>">
                    <?php echo esc_html($field['label']); ?> (<?php echo esc_html($field['type']); ?>)
                    <a href="#" class="ccf-remove-field">Remove</a>
                </li>
            <?php endforeach; ?>
        </ul>
        <button id="ccf-add-field">Add Field</button>
    </div>
    <script type="text/html" id="ccf-field-template">
        <li class="ccf-field">
            <input type="hidden" name="ccf_form_fields[]" value="">
            <input type="text" class="ccf-field-label" placeholder="Label">
            <select class="ccf-field-type">
                <option value="text">Text</option>
                <option value="email">Email</option>
                <option value="textarea">Textarea</option>
                <option value="file">File</option>
            </select>
            <a href="#" class="ccf-remove-field">Remove</a>
        </li>
    </script>
    <style>
        .ccf-field { margin-bottom: 10px; }
        .ccf-field input, .ccf-field select { margin-right: 10px; }
    </style>
    <script>
        (function($) {
            $(document).ready(function() {
                $('#ccf-add-field').on('click', function(e) {
                    e.preventDefault();
                    var template = $('#ccf-field-template').html();
                    $('#ccf-form-fields').append(template);
                });

                $('#ccf-form-fields').on('click', '.ccf-remove-field', function(e) {
                    e.preventDefault();
                    $(this).closest('.ccf-field').remove();
                });

                $('#ccf-form-fields').sortable({
                    placeholder: 'ccf-sortable-placeholder',
                    stop: function() {
                        $('#ccf-form-fields .ccf-field').each(function() {
                            var label = $(this).find('.ccf-field-label').val();
                            var type = $(this).find('.ccf-field-type').val();
                            var data = { label: label, type: type };
                            $(this).find('input[name="ccf_form_fields[]"]').val(JSON.stringify(data));
                        });
                    }
                });
            });
        })(jQuery);
    </script>
    <?php
}

// Function to save the meta box data.
function ccf_save_meta_box_data($post_id) {
    if (!isset($_POST['ccf_meta_box_nonce']) || !wp_verify_nonce($_POST['ccf_meta_box_nonce'], 'ccf_save_meta_box_data')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (isset($_POST['post_type']) && 'ccf_contact_form' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return;
        }
    } else {
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    }

    if (!isset($_POST['ccf_form_fields'])) {
        return;
    }

    // Sanitize and save form fields.
    $form_fields = array_map('sanitize_text_field', $_POST['ccf_form_fields']);
    update_post_meta($post_id, '_ccf_form_fields', json_encode($form_fields));
}
add_action('save_post', 'ccf_save_meta_box_data');
