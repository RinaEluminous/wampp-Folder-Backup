<?php
/*
Plugin Name: Custom Multiple Contact Forms
Description: A plugin to create multiple custom contact forms with fields.
Version: 1.0
Author: Your Name
*/

// Prevent direct access to the file.
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Include necessary files for the plugin to function.
include_once plugin_dir_path(__FILE__) . 'includes/post-types.php';
include_once plugin_dir_path(__FILE__) . 'includes/meta-boxes.php';
include_once plugin_dir_path(__FILE__) . 'includes/shortcodes.php';
include_once plugin_dir_path(__FILE__) . 'includes/form-handler.php';

// Add an admin menu for the plugin.
function ccf_admin_menu() {
    add_menu_page(
        'Multiple Contact Forms', // Page title.
        'Multiple Forms', // Menu title.
        'manage_options', // Capability required to access the menu.
        'ccf_contact_forms', // Menu slug.
        'ccf_contact_forms_page', // Callback function to render the menu page.
        'dashicons-email', // Menu icon.
        6 // Menu position.
    );
}
add_action('admin_menu', 'ccf_admin_menu');

// Callback function to render the contact forms admin page.
function ccf_contact_forms_page() {
    ?>
    <div class="wrap">
        <h1>Contact Forms</h1>
        <p>Here you can manage your custom contact forms.</p>
        <ul>
            <li><a href="<?php echo admin_url('edit.php?post_type=ccf_contact_form'); ?>">All Contact Forms</a></li>
            <li><a href="<?php echo admin_url('post-new.php?post_type=ccf_contact_form'); ?>">Add New Contact Form</a></li>
        </ul>
    </div>
    <?php
}
?>
