<?php
/*
Plugin Name: Multiple Forms Generator
Description: A plugin to create multiple forms dynamically with various field types.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Include the shortcode handler
include_once(plugin_dir_path(__FILE__) . 'includes/shortcode-handler.php');

// Register the custom post type for forms
function mfg_register_form_post_type() {
    $labels = array(
        'name' => 'Forms',
        'singular_name' => 'Form',
        'add_new' => 'Add New Form',
        'add_new_item' => 'Add New Form',
        'edit_item' => 'Edit Form',
        'new_item' => 'New Form',
        'view_item' => 'View Form',
        'search_items' => 'Search Forms',
        'not_found' => 'No Forms found',
        'not_found_in_trash' => 'No Forms found in Trash',
        'menu_name' => 'Forms',
    );

    $args = array(
        'labels' => $labels,
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => 25,
        'supports' => array('title'),
    );

    register_post_type('mfg_form', $args);
}
add_action('init', 'mfg_register_form_post_type');

// Add meta box for form builder
function mfg_add_meta_box() {
    add_meta_box(
        'mfg_form_builder',
        'Form Builder',
        'mfg_form_builder_callback',
        'mfg_form',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'mfg_add_meta_box');

function mfg_form_builder_callback($post) {
    wp_nonce_field('mfg_save_form_builder_data', 'mfg_form_builder_nonce');
    $form_code = get_post_meta($post->ID, '_mfg_form_code', true);
    ?>

    <div id="mfg-form-builder">
        <button type="button" class="button add-field-button" data-field-code="[text your-name]">Text</button>
        <button type="button" class="button add-field-button" data-field-code="[email your-email]">Email</button>
        <!-- Add more buttons for other fields like URL, tel, number, etc. -->
        <textarea id="form-editor" name="mfg_form_code" rows="10" style="width:100%;"><?php echo esc_textarea($form_code); ?></textarea>
    </div>

    <script>
        jQuery(document).ready(function($) {
            $('.add-field-button').on('click', function() {
                var fieldCode = $(this).data('field-code');
                var editor = $('#form-editor');
                editor.val(editor.val() + "\n" + fieldCode);
            });
        });
    </script>

    <?php
}

function mfg_save_form_builder_data($post_id) {
    if (!isset($_POST['mfg_form_builder_nonce']) || !wp_verify_nonce($_POST['mfg_form_builder_nonce'], 'mfg_save_form_builder_data')) {
        return;
    }

    if (isset($_POST['mfg_form_code'])) {
        update_post_meta($post_id, '_mfg_form_code', sanitize_textarea_field($_POST['mfg_form_code']));
    }
}
add_action('save_post', 'mfg_save_form_builder_data');

// Enqueue admin scripts and styles
function mfg_enqueue_admin_scripts($hook) {
    if ('post.php' != $hook && 'post-new.php' != $hook) {
        return;
    }

    wp_enqueue_script('mfg-form-builder-js', plugin_dir_url(__FILE__) . 'admin/form-builder.js', array('jquery'), null, true);
    wp_enqueue_style('mfg-form-builder-css', plugin_dir_url(__FILE__) . 'admin/form-builder.css');
}
add_action('admin_enqueue_scripts', 'mfg_enqueue_admin_scripts');

// Add custom columns to the Forms post type
function mfg_add_custom_columns($columns) {
    $columns['shortcode'] = 'Shortcode';
    return $columns;
}
add_filter('manage_mfg_form_posts_columns', 'mfg_add_custom_columns');

function mfg_custom_column_content($column, $post_id) {
    if ($column == 'shortcode') {
        $post = get_post($post_id);
        echo '[mfg_form id="' . $post_id . '" title="' . esc_attr($post->post_title) . '"]';
    }
}
add_action('manage_mfg_form_posts_custom_column', 'mfg_custom_column_content', 10, 2);

function mfg_sortable_columns($columns) {
    $columns['shortcode'] = 'shortcode';
    return $columns;
}
add_filter('manage_edit-mfg_form_sortable_columns', 'mfg_sortable_columns');
