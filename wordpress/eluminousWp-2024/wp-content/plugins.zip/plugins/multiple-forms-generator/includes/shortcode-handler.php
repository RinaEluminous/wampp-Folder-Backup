<?php
function mfg_render_custom_form($atts) {
    $atts = shortcode_atts(array(
        'id' => '',
    ), $atts);

    if (empty($atts['id'])) {
        return 'Form ID is missing.';
    }

    $form_code = get_post_meta($atts['id'], '_mfg_form_code', true);

    if (empty($form_code)) {
        return 'Form not found.';
    }

    $form_output = '<form method="post">' . do_shortcode($form_code) . '</form>';

    return $form_output;
}
add_shortcode('mfg_form', 'mfg_render_custom_form');

add_shortcode('mfg_form', 'mfg_render_custom_form');
// Handle form submission
function mfg_handle_form_submission() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Add your form submission handling logic here
        // For example, send an email, store data, etc.
        
        // Example: Send an email
        $to = 'you@example.com';
        $subject = 'New Form Submission';
        $message = 'You have received a new form submission.';
        wp_mail($to, $subject, $message);

        // Redirect or display a thank you message
        echo '<p>Thank you for your submission!</p>';
    }
}
add_action('wp', 'mfg_handle_form_submission');
