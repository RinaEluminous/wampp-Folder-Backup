jQuery(document).ready(function($) {
    $('.add-field-button').on('click', function() {
        var fieldCode = $(this).data('field-code');
        var editor = $('#form-editor');
        editor.val(editor.val() + "\n" + fieldCode);
    });
});
