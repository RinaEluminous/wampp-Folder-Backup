<?php 
/* 
*Plugin Name: WpCust Like/Dislike
 * Plugin URI: http://localhost/wordpress/eluminousWp-2024/
 * Description: Just another like dislike. Simple but flexible.
 * Author: WpCust.Rp
 * Author URI: https://ideasilo.wordpress.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Version: 5.9.5
 * Requires at least: 6.3
 *Requires PHP: 7.4
 * Text Domain: wpCustLike
 
*/

//if this file called directly,abort
if(!defined('WPINC')){
    exist();
}

if(!defined('WPCust_PLUGIN_VERSION')){
    defined('WPCust_PLUGIN_VERSION', '1.0.0');
}

if(!defined('WPCust_PLUGIN_DIR')){
    defined('WPCust_PLUGIN_DIR', plugin_dir_url(__FILE__));
}


if(!function_exists('wpcust_plugin_scripts')){
function wpcust_plugin_scripts(){

    //you can include any javascript file in this
    wp_enqueue_style('wpcust-css',WPCust_PLUGIN_DIR.'assets/css/style.css','jQuery','1.0.0',true);
    /* you can include any javascript file in this ---
     jQuery-it is the added conditin if jQuery is included then and script will be loaded gave version also for this and true is defined to load script at footer if you do it false then it will be load at header location */
    wp_enqueue_script('wpcust-js',WPCust_PLUGIN_DIR.'assets/js/main.js','jQuery','1.0.0',true);
    

}
add_action('wp_enqueue_scripts','wpcust_plugin_scripts');

}


?>
