<?php 
/* 
* Plugin Name: WpCust Like/Dislike
* Plugin URI: http://localhost/wordpress/eluminousWp-2024/
* Description: Just another like dislike. Simple but flexible.
* Author: WpCust.Rp
* Author URI: https://ideasilo.wordpress.com/
* License: GPL v2 or later
* License URI: https://www.gnu.org/licenses/gpl-2.0.html
* Version: 5.9.5
* Requires at least: 6.3
* Requires PHP: 7.4
* Text Domain: wpCustLike
*/

// If this file is called directly, abort.
if (!defined('WPINC')) {
    exit;
}

// Define plugin version
if (!defined('WPCust_PLUGIN_VERSION')) {
    define('WPCust_PLUGIN_VERSION', '1.0.0');
}

// Define plugin directory URL
if (!defined('WPCust_PLUGIN_DIR')) {
    define('WPCust_PLUGIN_DIR', plugin_dir_url(__FILE__));
}

/* Add js and css files */

// Enqueue scripts and styles
if (!function_exists('wpcust_plugin_scripts')) {
    function wpcust_plugin_scripts() {
        // Log to confirm the function is called
        error_log('WpCust Like/Dislike enqueue function called');
        // Enqueue CSS file
        $css_file = WPCust_PLUGIN_DIR . 'assets/css/style.css';
        wp_enqueue_style('wpcust-css', $css_file, array(), '1.0.0', 'all');
        
        // Enqueue JavaScript file
        $js_file = WPCust_PLUGIN_DIR . 'assets/js/main.js';
        wp_enqueue_script('wpcust-js', $js_file, array('jquery'), '1.0.0', true);

        // Log to confirm files are enqueued
        error_log('CSS file path: ' . $css_file);
        error_log('JS file path: ' . $js_file);
    }
    add_action('wp_enqueue_scripts', 'wpcust_plugin_scripts');
}

/* Add custom Menu  */
// Register menu page
// if (!function_exists('wpcust_register_menu_page')) {
//     function wpcust_register_menu_page() {
//         add_menu_page(
//             'WPAQ Like System',           // Page title
//             'WPAQ Settings',              // Menu title
//             'manage_options',             // Capability
//             'wpac-setting',               // Menu slug
//             'wpcust_setting_page_html',   // Callback function
//             'dashicons-thumbs-up',        // Icon URL
//             30                            // Position
//         );
//     }
//     add_action('admin_menu', 'wpcust_register_menu_page');
// }

// Register sub menu page
if (!function_exists('wpcust_register_sub_menu_page')) {
    function wpcust_register_sub_menu_page() {
        error_log('Registering WPAQ Settings submenu');
        add_submenu_page(
            'tools.php',                  // Parent slug
            'WPAQ Like System',           // Page title
            'WPAQ Settings submenu',              // Menu title
            'manage_options',             // Capability
            'wpac-setting',               // Menu slug
            'wpcust_setting_page_html'    // Callback function
        );
    }
    add_action('admin_menu', 'wpcust_register_sub_menu_page');
}


// Callback function to render the settings page
if (!function_exists('wpcust_setting_page_html')) {
    function wpcust_setting_page_html() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('WPAQ Settings', 'wpCustLike'); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('wpac_setting_group');
                do_settings_sections('wpac-setting');
                submit_button(__('Save Settings', 'wpCustLike'));
                ?>
            </form>
        </div>
        <?php
    }
}


?>
